//
//  RoundBooton.swift
//  SafeStreet
//
//  Created by arash bahariye on 04/11/2019.
//  Copyright © 2019 arash bahariye. All rights reserved.
//
import UIKit

var cornerRadius: CGFloat = 15 {
    didSet {
        refreshCorners(value: cornerRadius)
    }
}

@IBDesignable class RoundButton: UIButton {
    override init(frame: CGRect) {
        super.init(frame: frame)
        sharedInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        sharedInit()
    }
    
    override func prepareForInterfaceBuilder() {
        sharedInit()
    }
    
    func sharedInit() {
        // Common logic goes here
    }
    func refreshCorners(value: CGFloat) {
        layer.cornerRadius = value
    }
}


