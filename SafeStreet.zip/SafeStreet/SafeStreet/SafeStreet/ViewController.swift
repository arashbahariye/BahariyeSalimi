//
//  ViewController.swift
//  SafeStreet
//
//  Created by arash bahariye on 04/11/2019.
//  Copyright © 2019 arash bahariye. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
